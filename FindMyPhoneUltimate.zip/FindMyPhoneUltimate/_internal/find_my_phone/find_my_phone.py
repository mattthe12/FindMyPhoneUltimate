# find_my_phone_ultimate.py
# -*- coding: utf-8 -*-
"""
ULTIMATE Find My Phone PRO – FULLY FIXED & WORKING
NumVerify + Name + Location + Export + Search + API Settings
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import re
import requests
import threading
import json
import csv
from datetime import datetime
from pathlib import Path
import webbrowser
import logging

# -------------------------------------------------
# CONFIG & LOGGING
# -------------------------------------------------
CONFIG_FILE = Path("config.json")
LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(exist_ok=True)
HISTORY_FILE = Path("lookup_history.json")

def load_config():
    if CONFIG_FILE.is_file():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {"api_key": "", "theme": "light", "max_history": 1000}

def save_config(cfg):
    try:
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as e:
        logging.error(f"Config save error: {e}")

CONFIG = load_config()
API_KEY = CONFIG.get("api_key", "")
THEME = CONFIG.get("theme", "light")
MAX_HISTORY = CONFIG.get("max_history", 1000)

logging.basicConfig(
    filename=LOGS_DIR / "app.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

last_lookup_time = 0
LOOKUP_COOLDOWN = 1.0

# -------------------------------------------------
# Helpers
# -------------------------------------------------
DIGIT_RE = re.compile(r"[^\d]")

def clean_phone(raw: str) -> str:
    digits = DIGIT_RE.sub("", raw.strip())
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    elif len(digits) == 10:
        digits = "1" + digits
    return "+" + digits

def format_display(e164: str) -> str:
    if e164.startswith("+1") and len(e164) == 12:
        n = e164[2:]
        return f"+1 ({n[:3]}) {n[3:6]}-{n[6:]}"
    return e164

def load_history() -> list:
    if HISTORY_FILE.is_file():
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            for rec in data:
                if 'name' not in rec:
                    rec['name'] = "Not available"
            return data[-MAX_HISTORY:]
        except Exception as e:
            logging.error(f"History load error: {e}")
            return []
    return []

def save_history(records: list):
    try:
        HISTORY_FILE.write_text(json.dumps(records[-MAX_HISTORY:], indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        logging.error(f"History save error: {e}")

# -------------------------------------------------
# APIs
# -------------------------------------------------
def lookup_real(e164: str) -> dict | None:
    if not API_KEY:
        return {"error": "API key not set. Go to Settings."}
    url = "http://apilayer.net/api/validate"
    params = {
        "access_key": API_KEY,
        "number": e164,
        "country_code": "",
        "format": 1
    }
    try:
        r = requests.get(url, params=params, timeout=12)
        data = r.json()
        if not data.get("valid"):
            return None

        carrier = data.get("carrier", "N/A")
        location = data.get("location", "N/A")
        country = data.get("country_name", "N/A")

        name = "Not available"
        carrier_lower = carrier.lower()
        if " - " in carrier:
            name = carrier.split(" - ", 1)[-1].strip()
        elif " (" in carrier:
            name = carrier.split(" (", 1)[0].rsplit(" ", 1)[-1].strip()
        elif any(x in carrier_lower for x in ["wireless", "mobile", "telecom"]):
            words = carrier.split()
            for w in reversed(words):
                if w.isalpha() and len(w) > 2:
                    name = w
                    break

        return {
            "name": name,
            "carrier": carrier,
            "line_type": data.get("line_type", "N/A"),
            "location": f"{location}, {country}".strip(", ")
        }
    except Exception as e:
        return {"error": f"API Error: {e}"}

def get_my_location() -> dict | None:
    try:
        r = requests.get("http://ip-api.com/json/", timeout=8)
        data = r.json()
        if data.get("status") == "fail":
            return None
        return data
    except:
        return None

# -------------------------------------------------
# PRO INPUT WIDGET
# -------------------------------------------------
class PhoneEntry(ttk.Entry):
    def __init__(self, master, on_lookup=None, **kw):
        super().__init__(master, **kw)
        self.on_lookup = on_lookup
        self._raw_value = ""
        self._formatted_value = ""
        self.bind("<KeyRelease>", self._on_key_release)
        self.bind("<FocusOut>", self._on_focus_out)
        self.bind("<Control-v>", self._on_paste)

    def _on_paste(self, event=None):
        self.after(50, self._trigger_lookup_if_valid)

    def _trigger_lookup_if_valid(self):
        if self.on_lookup and len(DIGIT_RE.sub("", self.get())) >= 10:
            self.on_lookup()

    def _on_key_release(self, event=None):
        raw = self.get()
        if raw == self._formatted_value:
            return

        digits = DIGIT_RE.sub("", raw)
        if not digits:
            self._raw_value = self._formatted_value = ""
            self.delete(0, tk.END)
            return

        clean = clean_phone(digits)
        formatted = format_display(clean)
        if formatted != self._formatted_value:
            cursor = self.index(tk.INSERT)
            self._raw_value = digits
            self._formatted_value = formatted
            self.delete(0, tk.END)
            self.insert(0, formatted)
            new_pos = self._digit_to_pos(len(digits))
            self.icursor(new_pos)

    def _on_focus_out(self, event=None):
        digits = DIGIT_RE.sub("", self.get())
        if digits:
            clean = clean_phone(digits)
            formatted = format_display(clean)
            if formatted != self.get():
                self.delete(0, tk.END)
                self.insert(0, formatted)

    def _digit_to_pos(self, digit_count: int) -> int:
        if digit_count == 0:
            return 0
        test_clean = clean_phone("1" * digit_count)
        return len(format_display(test_clean))

    def get_clean(self) -> str:
        return clean_phone(self.get())

# -------------------------------------------------
# TOOLTIP
# -------------------------------------------------
class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip = None
        widget.bind("<Enter>", self.show)
        widget.bind("<Leave>", self.hide)

    def show(self, event=None):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        label = tk.Label(self.tip, text=self.text, background="#ffffe0", relief="solid", borderwidth=1, font=("Arial", 9))
        label.pack()

    def hide(self, event=None):
        if self.tip:
            self.tip.destroy()
            self.tip = None

# -------------------------------------------------
# MAIN APP
# -------------------------------------------------
class FindPhoneUltimate(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Find My Phone – ULTIMATE PRO")
        self.geometry("820x720")
        self.minsize(700, 600)
        self.configure(padx=15, pady=15)

        self.dark = (THEME == "dark")
        self.style = ttk.Style(self)
        self.style.theme_use("clam")
        self.style.configure("TButton", padding=6)

        self.history = load_history()
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", self._filter_history)

        self._create_widgets()
        self._apply_theme()

    def _create_widgets(self):
        # Header
        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0, 10))
        ttk.Label(header, text="Find My Phone ULTIMATE", font=("Arial", 22, "bold")).pack(side="left")
        self.theme_btn = ttk.Button(header, text="Dark Mode", command=self.toggle_theme)
        self.theme_btn.pack(side="left", padx=10)
        ToolTip(self.theme_btn, "Toggle dark/light theme")

        self.settings_btn = ttk.Button(header, text="Settings", command=self.open_settings)
        self.settings_btn.pack(side="right")
        ToolTip(self.settings_btn, "API Key & Preferences")

        # Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, pady=10)

        # === TAB 1: PHONE LOOKUP ===
        tab1 = ttk.Frame(self.notebook)
        self.notebook.add(tab1, text="Phone Lookup")

        inp_frame = ttk.Frame(tab1)
        inp_frame.pack(fill="x", pady=10)
        ttk.Label(inp_frame, text="Phone:", font=("Arial", 11)).grid(row=0, column=0, sticky="w", padx=(0, 5))
        self.entry = PhoneEntry(inp_frame, on_lookup=self.start_lookup, font=("Courier", 14), width=35)
        self.entry.grid(row=0, column=1, sticky="ew")
        inp_frame.columnconfigure(1, weight=1)
        ToolTip(self.entry, "Type or paste a phone number")

        btns = ttk.Frame(tab1)
        btns.pack(fill="x", pady=8)
        self.lookup_btn = ttk.Button(btns, text="Lookup", style="Accent.TButton", command=self.start_lookup)
        self.lookup_btn.pack(side="left", padx=4)
        self.copy_full_btn = ttk.Button(btns, text="Copy Full", command=self.copy_result)
        self.copy_full_btn.pack(side="left", padx=4)
        self.copy_phone_btn = ttk.Button(btns, text="Copy Phone", command=self.copy_phone_only)
        self.copy_phone_btn.pack(side="left", padx=4)
        self.clear_btn = ttk.Button(btns, text="Clear", command=self.clear_result)
        self.clear_btn.pack(side="left", padx=4)

        self.prog = ttk.Progressbar(tab1, mode="indeterminate")
        self.prog.pack(fill="x", pady=6)

        res_frame = ttk.LabelFrame(tab1, text="Result")
        res_frame.pack(fill="both", expand=True, pady=8)
        self.result = tk.Text(res_frame, font=("Consolas", 11), wrap="word", state="disabled")
        self.result.pack(fill="both", expand=True, padx=8, pady=6)

        # === TAB 2: MY LOCATION ===
        tab2 = ttk.Frame(self.notebook)
        self.notebook.add(tab2, text="My Location")

        loc_btn = ttk.Button(tab2, text="Get My Location", command=self.get_my_location)
        loc_btn.pack(pady=20)
        ToolTip(loc_btn, "Show your current city, ISP, and map")

        self.loc_result = tk.Text(tab2, font=("Consolas", 11), height=15, state="disabled")
        self.loc_result.pack(fill="both", expand=True, padx=20, pady=10)

        # === TAB 3: HISTORY ===
        tab3 = ttk.Frame(self.notebook)
        self.notebook.add(tab3, text="History")

        search_frame = ttk.Frame(tab3)
        search_frame.pack(fill="x", pady=5)
        ttk.Label(search_frame, text="Search:").pack(side="left")
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.pack(side="left", fill="x", expand=True, padx=5)
        export_btn = ttk.Button(search_frame, text="Export CSV", command=self.export_csv)
        export_btn.pack(side="right")
        ToolTip(export_btn, "Save history to CSV")

        hist_frame = ttk.Frame(tab3)
        hist_frame.pack(fill="both", expand=True, pady=5)
        self.hist_list = tk.Listbox(hist_frame, font=("Arial", 10))
        self.hist_list.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(hist_frame, orient="vertical", command=self.hist_list.yview)
        scrollbar.pack(side="right", fill="y")
        self.hist_list.config(yscrollcommand=scrollbar.set)

        self.hist_list.bind("<<ListboxSelect>>", self._show_hist)
        self.hist_list.bind("<Double-1>", lambda e: self._lookup_from_history())
        self.hist_list.bind("<Button-3>", self._show_context_menu)

        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Lookup", command=self._lookup_from_history)
        self.context_menu.add_command(label="Delete", command=self._delete_history_entry)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Clear All", command=self.clear_history)

        self._refresh_hist()

    def open_settings(self):
        SettingsWindow(self)

    def _show_context_menu(self, event):
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def _lookup_from_history(self):
        sel = self.hist_list.curselection()
        if not sel:
            return
        idx = len(self.history) - 1 - sel[0]
        rec = self.history[idx]
        self.entry.delete(0, tk.END)
        self.entry.insert(0, rec["display"])
        self.notebook.select(0)
        self.start_lookup()

    def _delete_history_entry(self):
        sel = self.hist_list.curselection()
        if not sel:
            return
        if messagebox.askyesno("Delete", "Remove this entry?"):
            idx = len(self.history) - 1 - sel[0]
            del self.history[idx]
            save_history(self.history)
            self._refresh_hist()

    def _filter_history(self, *args):
        query = self.search_var.get().lower()
        self.hist_list.delete(0, tk.END)
        for rec in reversed(self.history):
            if query in rec["display"].lower() or query in rec.get("name", "").lower():
                name_part = f" ({rec['name']})" if rec['name'] != "Not available" else ""
                self.hist_list.insert("end", f"{rec['timestamp']} – {rec['display']}{name_part}")

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            title="Export History"
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Time", "Phone", "Name", "Carrier", "Type", "Location"])
                for rec in reversed(self.history):
                    writer.writerow([
                        rec["timestamp"],
                        rec["display"],
                        rec.get("name", "N/A"),
                        rec.get("carrier", "N/A"),
                        rec.get("type", "N/A"),
                        rec.get("location", "N/A")
                    ])
            messagebox.showinfo("Exported", f"Saved to {path}")
        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {e}")

    def get_my_location(self):
        self.loc_result.configure(state="normal")
        self.loc_result.delete("1.0", "end")
        self.loc_result.insert("end", "Fetching...\n")
        self.loc_result.configure(state="disabled")

        def fetch():
            info = get_my_location()
            def update():
                self.loc_result.configure(state="normal")
                self.loc_result.delete("1.0", "end")
                if not info:
                    self.loc_result.insert("end", "Could not detect location.\n", "red")
                else:
                    txt = (
                        f"IP: {info.get('query')}\n"
                        f"Location: {info.get('city')}, {info.get('regionName')}, {info.get('country')}\n"
                        f"ISP: {info.get('isp')}\n"
                        f"Org: {info.get('org')}\n"
                        f"Coords: {info.get('lat')}, {info.get('lon')}\n"
                        f"Timezone: {info.get('timezone')}\n\n"
                        f"Open in Google Maps: "
                    )
                    self.loc_result.insert("end", txt)
                    self.loc_result.insert("end", "CLICK HERE", "link")
                    self.loc_result.tag_config("link", foreground="blue", underline=1)
                    self.loc_result.tag_bind("link", "<Button-1>", lambda e: webbrowser.open(
                        f"https://www.google.com/maps?q={info['lat']},{info['lon']}"
                    ))
                self.loc_result.configure(state="disabled")
            self.after(0, update)
        threading.Thread(target=fetch, daemon=True).start()

    def start_lookup(self):
        global last_lookup_time, API_KEY
        API_KEY = CONFIG.get("api_key", "")
        if not API_KEY:
            messagebox.showwarning("API Key", "Set your NumVerify API key in Settings.")
            self.open_settings()
            return

        now = datetime.now().timestamp()
        if now - last_lookup_time < LOOKUP_COOLDOWN:
            messagebox.showwarning("Slow Down", "Wait 1 second between lookups.")
            return
        last_lookup_time = now

        e164 = self.entry.get_clean()

        # FIXED: Accept +1xxxxxxxxxx (12 chars) or any valid E.164
        if not (e164.startswith("+1") and len(e164) == 12) and not (e164[0] == "+" and 8 <= len(e164) <= 15):
            messagebox.showwarning("Invalid", "Enter a valid phone number.")
            return

        self.result.configure(state="normal")
        self.result.delete("1.0", "end")
        self.result.configure(state="disabled")
        self.copy_full_btn.configure(state="disabled")
        self.copy_phone_btn.configure(state="disabled")
        self.prog.start(10)

        threading.Thread(target=self._do_lookup, args=(e164,), daemon=True).start()

    def _do_lookup(self, e164: str):
        info = lookup_real(e164)
        def update():
            self.prog.stop()
            self.result.configure(state="normal")
            self.result.delete("1.0", "end")
            if not info:
                self._append("Invalid or not found.\n", "red")
            elif "error" in info:
                self._append(f"{info['error']}\n", "red")
            else:
                txt = (
                    f"Number   : {format_display(e164)}\n"
                    f"Name     : {info.get('name')}\n"
                    f"Carrier  : {info.get('carrier')}\n"
                    f"Type     : {info.get('line_type')}\n"
                    f"Location : {info.get('location')}\n"
                )
                self._append(txt, "green")
                self.copy_full_btn.configure(state="normal")
                self.copy_phone_btn.configure(state="normal")

                rec = {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "phone": e164,
                    "display": format_display(e164),
                    "name": info.get("name"),
                    "carrier": info.get("carrier"),
                    "type": info.get("line_type"),
                    "location": info.get("location")
                }
                self.history.append(rec)
                save_history(self.history)
                self._refresh_hist()
            self.result.configure(state="disabled")
        self.after(0, update)

    def _append(self, text: str, tag: str):
        self.result.insert("end", text, tag)
        self.result.tag_config("green", foreground="#2e7d32")
        self.result.tag_config("red", foreground="#c62828")

    def copy_result(self):
        txt = self.result.get("1.0", "end").strip()
        if txt:
            self.clipboard_clear()
            self.clipboard_append(txt)
            messagebox.showinfo("Copied", "Full result copied!")

    def copy_phone_only(self):
        phone = self.entry.get()
        if phone:
            self.clipboard_clear()
            self.clipboard_append(phone)
            messagebox.showinfo("Copied", f"Phone copied: {phone}")

    def clear_result(self):
        self.result.configure(state="normal")
        self.result.delete("1.0", "end")
        self.result.configure(state="disabled")
        self.copy_full_btn.configure(state="disabled")
        self.copy_phone_btn.configure(state="disabled")

    def _refresh_hist(self):
        self._filter_history()

    def _show_hist(self, _):
        sel = self.hist_list.curselection()
        if not sel:
            return
        idx = len(self.history) - 1 - sel[0]
        rec = self.history[idx]
        detail = (
            f"Number   : {rec.get('display', 'N/A')}\n"
            f"Name     : {rec.get('name', 'Not available')}\n"
            f"Carrier  : {rec.get('carrier', 'N/A')}\n"
            f"Type     : {rec.get('type', 'N/A')}\n"
            f"Location : {rec.get('location', 'N/A')}\n"
            f"Time     : {rec.get('timestamp', 'N/A')}"
        )
        self.result.configure(state="normal")
        self.result.delete("1.0", "end")
        self._append(detail, "green")
        self.result.configure(state="disabled")
        self.copy_full_btn.configure(state="normal")
        self.copy_phone_btn.configure(state="normal")

    def clear_history(self):
        if messagebox.askyesno("Clear All", "Delete ALL history?"):
            self.history.clear()
            save_history(self.history)
            self._refresh_hist()
            self.clear_result()

    def _apply_theme(self):
        if self.dark:
            self._set_dark_theme()
            self.theme_btn.configure(text="Light Mode")
        else:
            self._set_light_theme()
            self.theme_btn.configure(text="Dark Mode")

    def _set_light_theme(self):
        self.configure(bg="#fafafa")
        self.style.configure(".", background="#fafafa", foreground="#222")
        self.style.map("Accent.TButton", background=[("active", "#0078d4")])
        self.style.configure("Accent.TButton", background="#0078d4", foreground="white")
        self.result.configure(bg="#f8f8f8", fg="#222")
        self.loc_result.configure(bg="#f8f8f8", fg="#222")

    def _set_dark_theme(self):
        self.configure(bg="#1e1e1e")
        self.style.configure(".", background="#1e1e1e", foreground="#ddd")
        self.style.map("Accent.TButton", background=[("active", "#0a84ff")])
        self.style.configure("Accent.TButton", background="#0a84ff", foreground="white")
        self.result.configure(bg="#2d2d2d", fg="#ddd")
        self.loc_result.configure(bg="#2d2d2d", fg="#ddd")

    def toggle_theme(self):
        global CONFIG, THEME
        self.dark = not self.dark
        THEME = "dark" if self.dark else "light"
        CONFIG["theme"] = THEME
        save_config(CONFIG)
        self._apply_theme()

# -------------------------------------------------
# SETTINGS WINDOW
# -------------------------------------------------
class SettingsWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Settings")
        self.geometry("400x300")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="NumVerify API Key:", font=("Arial", 10)).pack(anchor="w")
        self.api_var = tk.StringVar(value=CONFIG.get("api_key", ""))
        api_entry = ttk.Entry(frame, textvariable=self.api_var, width=40, show="*")
        api_entry.pack(pady=5, fill="x")

        ttk.Label(frame, text="Max History Entries:", font=("Arial", 10)).pack(anchor="w", pady=(15,0))
        self.max_var = tk.StringVar(value=str(CONFIG.get("max_history", 1000)))
        max_entry = ttk.Entry(frame, textvariable=self.max_var, width=10)
        max_entry.pack(anchor="w", pady=5)

        btn_frame = ttk.Frame(frame)
        btn_frame.pack(fill="x", pady=20)
        ttk.Button(btn_frame, text="Save", command=self.save).pack(side="right", padx=5)
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(side="right")

    def save(self):
        global CONFIG, API_KEY, MAX_HISTORY
        key = self.api_var.get().strip()
        try:
            max_hist = int(self.max_var.get())
            if max_hist < 10: raise ValueError
        except:
            messagebox.showerror("Invalid", "Max history must be ≥ 10")
            return

        CONFIG["api_key"] = key
        CONFIG["max_history"] = max_hist
        API_KEY = key
        MAX_HISTORY = max_hist
        save_config(CONFIG)
        messagebox.showinfo("Saved", "Settings saved! Restart app for full effect.")
        self.destroy()

# -------------------------------------------------
# RUN
# -------------------------------------------------
if __name__ == "__main__":
    app = FindPhoneUltimate()
    app.mainloop()