# where_am_i.py
#!/usr/bin/env python3
"""
Where Am I? – Real-time Location from Public IP
Shows: City, ISP, Coordinates, Google Maps Link
"""

import requests
import webbrowser
from datetime import datetime

URL = "http://ip-api.com/json/"

def get_location():
    try:
        r = requests.get(URL, timeout=10)
        data = r.json()
        if data.get("status") == "fail":
            print(f"Error: {data.get('message')}")
            return None
        return data
    except Exception as e:
        print(f"Network error: {e}")
        return None

def main():
    print("Fetching your location...")
    info = get_location()
    if not info:
        return

    print("\n" + "="*50)
    print("YOUR CURRENT LOCATION")
    print("="*50)
    print(f"IP        : {info.get('query')}")
    print(f"Country   : {info.get('country')} ({info.get('countryCode')})")
    print(f"Region    : {info.get('regionName')} ({info.get('region')})")
    print(f"City      : {info.get('city')}")
    print(f"ZIP       : {info.get('zip')}")
    print(f"ISP       : {info.get('isp')}")
    print(f"Org       : {info.get('org')}")
    print(f"Lat/Lon   : {info.get('lat')}, {info.get('lon')}")
    print(f"Timezone  : {info.get('timezone')}")
    print(f"Time      : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*50)

    maps_url = f"https://www.google.com/maps?q={info['lat']},{info['lon']}"
    print(f"Open in Maps: {maps_url}")

    if input("\nOpen in browser? (y/n): ").strip().lower() == 'y':
        webbrowser.open(maps_url)

if __name__ == "__main__":
    main()